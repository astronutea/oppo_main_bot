BOT_TOKEN="7325765461:AAGt2mjVL3YiOAB6uN6_rA9CmdoP5EK23Yk"
PASSWORD="NaA6c-DMX8ENgHTu"
GAME_URL="https://t.me/StrongOPPOnut_bot/app"
SUPPORT_BOT_URL="https://t.me/StrongOPPOnut_support_bot"